package kr.colmap.driver;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class ColMapAccessibilityService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        // 1차판에서는 화면을 읽을 수 있는 연결만 준비합니다.
        // 실제 배민 화면의 텍스트/노드 구조를 확인한 뒤
        // 금액·거리·출발지·도착지·수락상태 추출 규칙을 별도 모듈로 넣습니다.
    }
    @Override public void onInterrupt() {}
}
