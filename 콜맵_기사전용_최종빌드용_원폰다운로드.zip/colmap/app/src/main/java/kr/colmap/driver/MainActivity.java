package kr.colmap.driver;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity implements LocationListener {
    private WebView web;
    private LocationManager locationManager;

    private final ActivityResultLauncher<String[]> locationPermission =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            boolean fine = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION));
            boolean coarse = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));
            if (fine || coarse) startGps();
            else web.evaluateJavascript("window.colmapGpsError('위치 권한이 허용되지 않았습니다.');", null);
        });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setGeolocationEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new NativeBridge(this), "NativeColMap");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.nativeAppResumed && window.nativeAppResumed();", null);
    }

    @Override protected void onPause() {
        super.onPause();
        // GPS updates are intentionally kept only while the activity is active in this first native build.
    }

    public void requestGps() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            locationPermission.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
        } else startGps();
    }

    private void startGps() {
        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        try {
            boolean fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            boolean coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            if (fine) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 2f, this);
            }
            if (fine || coarse) {
                try { locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 5f, this); } catch (Exception ignored) {}
            }
            Location last = null;
            try { last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER); } catch (Exception ignored) {}
            if (last == null) { try { last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); } catch (Exception ignored) {} }
            if (last != null) onLocationChanged(last);
            web.evaluateJavascript("window.colmapGpsReady();", null);
        } catch (Exception e) {
            web.evaluateJavascript("window.colmapGpsError(" + js(e.getMessage()) + ");", null);
        }
    }

    @Override public void onLocationChanged(Location loc) {
        if (web != null) {
            String script = String.format(java.util.Locale.US,
                "window.colmapGpsUpdate(%f,%f,%f);",
                loc.getLatitude(), loc.getLongitude(), loc.hasAccuracy()?loc.getAccuracy():-1f);
            web.evaluateJavascript(script, null);
        }
    }
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}

    private String js(String s) {
        if (s == null) s = "unknown";
        return "'" + s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ") + "'";
    }

    public class NativeBridge {
        private final Context ctx;
        NativeBridge(Context c){ctx=c;}

        @JavascriptInterface public void requestGps(){ MainActivity.this.runOnUiThread(MainActivity.this::requestGps); }

        @JavascriptInterface public void openAccessibilitySettings(){
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch(Exception e) {
                Toast.makeText(ctx, "접근성 설정을 열 수 없습니다.", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface public void openKakaoNavi(){
            // Official Kakao Navi SDK integration requires a registered native app key
            // and a destination. This button only attempts to launch the installed app.
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage("com.locnall.KimGiSa");
                if (launch != null) startActivity(launch);
                else Toast.makeText(ctx, "카카오내비 앱을 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
            } catch(Exception e) {
                Toast.makeText(ctx, "카카오내비 실행에 실패했습니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
