콜맵 APK 클라우드 빌드용 프로젝트

이 프로젝트는 휴대폰에서 직접 Android SDK/Gradle을 설치하지 않고 GitHub Actions로 APK를 빌드할 수 있도록 준비되어 있습니다.

1) GitHub에 새 저장소를 만들고 이 프로젝트의 파일을 올립니다.
2) 저장소의 Actions 탭에서 'Build ColMap APK'를 선택합니다.
3) 'Run workflow'를 누릅니다.
4) 빌드가 성공하면 workflow 실행 화면의 Artifacts에서 colmap-debug-apk를 다운로드합니다.
5) ZIP을 풀어 app-debug.apk를 휴대폰에 설치합니다.

주의: 이 방식은 실제 APK를 GitHub 서버에서 빌드하는 것이며, 이 작업환경에서 APK를 이미 빌드했다는 의미가 아닙니다.
