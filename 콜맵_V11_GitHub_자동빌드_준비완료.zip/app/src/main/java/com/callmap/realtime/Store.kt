package com.callmap.realtime
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
object Store {
 private const val P="callmap"; private const val K="records"
 fun add(c:Context, obj:JSONObject) { synchronized(this) {
  val p=c.getSharedPreferences(P,0); val a=JSONArray(p.getString(K,"[]"))
  val now=System.currentTimeMillis()
  // idempotency: same fingerprint within 8 seconds is ignored
  val fp=obj.optString("fingerprint")
  for(i in 0 until a.length()) if(a.getJSONObject(i).optString("fingerprint")==fp && now-a.getJSONObject(i).optLong("ts")<8000) return
  obj.put("id",UUID.randomUUID().toString()).put("ts",now); a.put(obj)
  p.edit().putString(K,a.toString()).apply()
 }}
 fun all(c:Context)=c.getSharedPreferences(P,0).getString(K,"[]")!!
}
