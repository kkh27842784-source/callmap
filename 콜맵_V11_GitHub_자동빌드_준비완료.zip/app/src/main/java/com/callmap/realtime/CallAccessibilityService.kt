package com.callmap.realtime

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject
import java.util.Locale

/**
 * 기존 v9 실시간 수집 엔진을 유지하면서 화면 텍스트를 구조화한다.
 * 자동 수락/거절은 수행하지 않는다.
 */
class CallAccessibilityService : AccessibilityService() {
    private var lastFingerprint = ""
    private var lastAt = 0L

    // 실제 배민 패키지명은 기기/배포 버전에 따라 달라질 수 있으므로 기본값은 제한하지 않는다.
    // 필요하면 아래 집합에 사용 중인 패키지를 넣어 필터링할 수 있다.
    private val allowedPackages = setOf<String>()

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (allowedPackages.isNotEmpty() && pkg !in allowedPackages) return

        val root = rootInActiveWindow ?: return
        val texts = ArrayList<String>()
        collect(root, texts)
        if (texts.isEmpty()) return

        val joined = texts.distinct().joinToString(" | ")
        val money = Regex("""(?<!\d)(?:₩\s*)?(\d{1,3}(?:,\d{3})*|\d{3,7})\s*원?""")
            .findAll(joined).mapNotNull { it.groupValues[1].replace(",", "").toLongOrNull() }
            .firstOrNull { it in 100..1_000_000 }
        val km = Regex("""(?<!\d)(\d+(?:\.\d+)?)\s*km\b""", RegexOption.IGNORE_CASE)
            .find(joined)?.groupValues?.get(1)?.toDoubleOrNull()

        // 금액+거리 둘 다 보이는 화면만 콜 후보로 기록한다.
        if (money == null || km == null || km !in 0.05..100.0) return

        val origin = extractLabeled(joined, listOf("픽업", "출발", "출발지", "상점"))
        val destination = extractLabeled(joined, listOf("배달", "도착", "도착지", "목적지", "주소"))
        val state = when {
            containsAny(joined, "배달완료", "배달 완료", "완료") -> "delivered"
            containsAny(joined, "취소", "취소됨", "주문취소") -> "cancelled"
            containsAny(joined, "픽업완료", "픽업 완료", "픽업") -> "pickup"
            containsAny(joined, "이동중", "이동 중", "배달중", "배달 중") -> "moving"
            else -> "received"
        }
        val difficulty = when {
            containsAny(joined, "3층", "4층", "5층", "계단", "엘리베이터 없음") -> "high"
            containsAny(joined, "주차", "골목", "상가") -> "medium"
            else -> "normal"
        }

        val relevant = texts.distinct().filter {
            it.contains("원") || it.contains("₩") ||
                Regex("""\d+(?:\.\d+)?\s*km""", RegexOption.IGNORE_CASE).containsMatchIn(it) ||
                containsAny(it, "픽업", "출발", "도착", "배달", "취소", "완료")
        }
        val raw = relevant.joinToString(" | ").take(4000)
        val fingerprint = "$pkg|$money|${"%.2f".format(Locale.US, km)}|$origin|$destination"
        val now = System.currentTimeMillis()
        if (fingerprint == lastFingerprint && now - lastAt < 5000) return
        lastFingerprint = fingerprint
        lastAt = now

        val o = JSONObject()
            .put("package", pkg)
            .put("money", money)
            .put("km", km)
            .put("won_per_km", Math.round(money.toDouble() / km))
            .put("origin", origin)
            .put("destination", destination)
            .put("state", state)
            .put("difficulty", difficulty)
            .put("raw", raw)
            .put("event_type", e.eventType)
            .put("fingerprint", fingerprint)

        Store.add(this, o)
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<String>) {
        n.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        n.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        for (i in 0 until n.childCount) n.getChild(i)?.let { child -> collect(child, out) }
    }

    private fun containsAny(s: String, vararg words: String) = words.any { s.contains(it, true) }

    private fun extractLabeled(s: String, labels: List<String>): String {
        val parts = s.split(" | ").map { it.trim() }.filter { it.isNotEmpty() }
        val i = parts.indexOfFirst { p -> labels.any { p.equals(it, true) || p.startsWith("$it:") || p.startsWith("$it ") } }
        if (i >= 0 && i + 1 < parts.size) return parts[i + 1].take(300)
        return ""
    }

    override fun onInterrupt() = Unit
}
