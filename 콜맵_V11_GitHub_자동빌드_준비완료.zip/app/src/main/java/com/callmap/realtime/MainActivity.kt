package com.callmap.realtime

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(18),dp(16),dp(16)) }
        val title = TextView(this).apply { text="📍 콜맵"; textSize=26f; setTextColor(Color.BLACK); setPadding(0,0,0,dp(8)) }
        root.addView(title)
        status = TextView(this).apply { textSize=15f; setTextColor(Color.DKGRAY); setPadding(0,0,0,dp(10)) }
        root.addView(status)

        fun btn(t:String, action:()->Unit){ root.addView(Button(this).apply{ text=t; setOnClickListener{action()} }) }
        btn("① 접근성 서비스 설정") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("② 위치 권한 허용") { requestLocation() }
        btn("③ GPS 기록 시작") { startGps() }
        btn("④ 최근 자동수집 기록") { showRecords() }
        btn("⑤ 데이터 초기화") { getSharedPreferences("callmap",0).edit().clear().apply(); updateStatus() }
        root.addView(TextView(this).apply {
            text="\n사용 순서\n접근성 허용 → 위치 권한 허용 → GPS 시작 → 배달앱 실행\n\n콜 화면의 금액·거리·출발/도착·상태 등을 화면에서 읽어 자동 기록합니다.\n자동 수락/거절은 하지 않습니다."
            textSize=14f; setTextColor(Color.DKGRAY)
        })
        setContentView(ScrollView(this).apply { addView(root) })
        updateStatus()
    }
    private fun requestLocation(){
        val p=ArrayList<String>()
        if(Build.VERSION.SDK_INT>=23){ p.add(Manifest.permission.ACCESS_FINE_LOCATION); p.add(Manifest.permission.ACCESS_COARSE_LOCATION) }
        if(Build.VERSION.SDK_INT>=33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        val need=p.filter{checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED}
        if(need.isNotEmpty()) requestPermissions(need.toTypedArray(),10) else startGps()
    }
    private fun startGps(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ requestLocation(); return }
        try { startForegroundService(Intent(this,LocationService::class.java)); Toast.makeText(this,"GPS 기록을 시작했습니다.",Toast.LENGTH_SHORT).show() } catch(e:Exception){ Toast.makeText(this,"GPS 시작 실패: ${e.message}",Toast.LENGTH_LONG).show() }
        updateStatus()
    }
    private fun showRecords(){
        val s=Store.all(this)
        if(s=="[]") Toast.makeText(this,"아직 자동수집 기록이 없습니다.",Toast.LENGTH_LONG).show()
        else TextView(this).also { it.text=s; it.textSize=12f; it.setPadding(dp(12),dp(12),dp(12),dp(12)); AlertDialog.Builder(this).setTitle("최근 자동수집 기록").setView(ScrollView(this).apply{addView(it)}).setPositiveButton("닫기",null).show() }
    }
    private fun updateStatus(){
        val enabled = try { Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(packageName)==true } catch(_:Exception){false}
        val loc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
        status.text="접근성: ${if(enabled)"ON" else "OFF"}  |  위치권한: ${if(loc)"ON" else "OFF"}\n배민 화면에서 감지된 콜은 자동 저장됩니다."
    }
    override fun onResume(){ super.onResume(); if(::status.isInitialized) updateStatus() }
}
