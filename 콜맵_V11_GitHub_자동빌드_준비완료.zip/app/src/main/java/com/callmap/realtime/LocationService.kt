package com.callmap.realtime
import android.app.*
import android.content.*
import android.os.IBinder
import android.os.Build
import com.google.android.gms.location.*
class LocationService: Service(){
 private lateinit var fused:FusedLocationProviderClient
 private val cb=object:LocationCallback(){override fun onLocationResult(r:LocationResult){ /* GPS persistence hook */ }}
 override fun onCreate(){super.onCreate();fused=LocationServices.getFusedLocationProviderClient(this)
  if(Build.VERSION.SDK_INT>=26){val ch=NotificationChannel("gps","콜맵 GPS",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager::class.java).createNotificationChannel(ch)}
  startForeground(1001,Notification.Builder(this,"gps").setContentTitle("콜맵 GPS 기록").setContentText("위치 기록 중").setSmallIcon(android.R.drawable.ic_menu_mylocation).build())
  val req=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,3000).setMinUpdateIntervalMillis(1500).build()
  fused.requestLocationUpdates(req,cb,mainLooper)
 }
 override fun onBind(i:Intent?):IBinder?=null
 override fun onDestroy(){fused.removeLocationUpdates(cb);super.onDestroy()}
}
